# Phase 1 Runtime Health Report

Overall status: WARN

Files directory: `C:\MT5PortableGoldMission\MQL5\Files`

## Checks

| Check | Status | Message |
| --- | --- | --- |
| decision_log | PASS | Found `C:\MT5PortableGoldMission\MQL5\Files\decision_log.csv` (455524 bytes). |
| startup_log | PASS | Found `C:\MT5PortableGoldMission\MQL5\Files\startup_log.csv` (1898 bytes). |
| shutdown_log | PASS | Found `C:\MT5PortableGoldMission\MQL5\Files\shutdown_log.csv` (2204 bytes). |
| decision_rows | PASS | Decision rows: 561. |
| latest_freshness | PASS | Latest row age is 2.2 minute(s); limit 15. |
| dry_run_lock | PASS | All decision rows stayed dry-run. |
| permission_lock | PASS | All decision rows kept permission false. |
| server_time_status | PASS | Latest row reports CLOCK_OK; historical non-CLOCK_OK rows: 1. |
| exact_duplicate_rows | PASS | No exact duplicate runtime rows found. |
| unique_bar_gaps | WARN | Larger-than-M5 gaps: 2; largest 2945 minute(s). |
| startup_shutdown_rows | PASS | Startup and shutdown logs are both present; shutdown rows exceed startup rows (14 > 9) after restart/test cycles. |

## Runtime Shape

- Decision rows: 561
- Startup rows: 9
- Shutdown rows: 14
- Unique run IDs: 5
- First unique M5 bar: 2026.05.22 11:00:00
- Latest unique M5 bar: 2026.05.26 19:30:00
- Larger-than-M5 gaps: 2
- Expected market-break gaps: 1

## Latest Row

| Run ID | Broker Time | Local Time | Bar Time | Dry Run | Permission | Server Time | BR Stage |
| --- | --- | --- | --- | --- | --- | --- | --- |
| phase1-dry-run-v0.6 | 2026.05.26 19:30:00 | 2026.05.27 00:59:58 | 2026.05.26 19:30:00 | true | false | CLOCK_OK | WAIT_LEVEL_BREAK_RETEST |

## Recent Gaps

| Left Bar | Right Bar | Minutes | Reason |
| --- | --- | --- | --- |
| 2026.05.22 20:55:00 | 2026.05.24 22:00:00 | 2945 | unexpected |
| 2026.05.25 18:25:00 | 2026.05.25 22:00:00 | 215 | unexpected |

## Rows By Run ID

| Run ID | Rows | First Bar | Latest Bar |
| --- | --- | --- | --- |
| phase1-dry-run-v0.6 | 557 | 2026.05.22 11:00:00 | 2026.05.26 19:30:00 |
| phase1-dry-run-v0.6-daily-lock-test | 1 | 2026.05.22 12:40:00 | 2026.05.22 12:40:00 |
| phase1-dry-run-v0.6-manual-lock-test | 1 | 2026.05.22 12:40:00 | 2026.05.22 12:40:00 |
| phase1-dry-run-v0.6-monthly-lock-test | 1 | 2026.05.22 12:40:00 | 2026.05.22 12:40:00 |
| phase1-dry-run-v0.6-weekly-lock-test | 1 | 2026.05.22 12:40:00 | 2026.05.22 12:40:00 |
