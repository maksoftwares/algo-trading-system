# Phase 3 Experimental Manifest

This report has no authority over Phase 2 readiness. PHASE2_READINESS_REPORT.md remains the sole real readiness authority.

Overall status: DIRTY_WORKTREE

## Snapshot

| Field | Value |
| --- | --- |
| Created at UTC | 2026-05-28T19:35:10.559110Z |
| Commit | 32c114a |
| Simulation status | EXPERIMENTAL_COST_SUSPEND_SCENARIO |
| Safety status | PASS |
| Working tree clean | False |
| Boundary | repo_only_no_mt5_deployment_no_phase2_status_change |

## Working Tree

```text
M agent.md
 M status.html
 M xau-usd/xauusd-phase0/outputs/reports/MEASURED_COST_MODEL.md
 M xau-usd/xauusd-phase0/outputs/reports/PHASE0_CONCENTRATION_FREQUENCY_NORMALIZED_AUDIT.md
 M xau-usd/xauusd-phase0/outputs/reports/PHASE0_REJECTED_CANDIDATE_GATE_AUDIT.md
 M xau-usd/xauusd-phase0/outputs/reports/spread_distribution_report.md
 M xau-usd/xauusd-phase1/docs/PHASE2_AUTHORIZATION_CHECKLIST.md
 M xau-usd/xauusd-phase1/docs/PHASE2_DEMO_TRANSITION_RUNBOOK.md
 M xau-usd/xauusd-phase1/docs/PHASE2_OPERATIONS_PREP.md
 M xau-usd/xauusd-phase1/docs/PHASE2_OWNER_APPROVAL_DRAFT.md
 M xau-usd/xauusd-phase1/docs/PHASE2_OWNER_APPROVAL_TEMPLATE.md
 M xau-usd/xauusd-phase1/docs/PHASE2_VPS_SELECTION_MATRIX.md
 M xau-usd/xauusd-phase1/outputs/reports/PHASE1_ACCEPTANCE_REPORT.md
 M xau-usd/xauusd-phase1/outputs/reports/PHASE1_DRY_RUN_LOG_REPORT.md
 M xau-usd/xauusd-phase1/outputs/reports/PHASE1_EXTERNAL_HEALTH.json
 M xau-usd/xauusd-phase1/outputs/reports/PHASE1_REVIEW_INDEX.md
 M xau-usd/xauusd-phase1/outputs/reports/PHASE1_RUNTIME_HEALTH_REPORT.md
 M xau-usd/xauusd-phase1/outputs/reports/PHASE1_SOAK_DRIFT_REPORT.md
 M xau-usd/xauusd-phase1/outputs/reports/PHASE1_SOAK_HISTORY.csv
 M xau-usd/xauusd-phase1/outputs/reports/PHASE1_SOAK_HISTORY_REPORT.md
 M xau-usd/xauusd-phase1/outputs/reports/PHASE1_STATUS_SUMMARY.json
 M xau-usd/xauusd-phase1/outputs/reports/PHASE2_DEMO_COUNTDOWN.json
 M xau-usd/xauusd-phase1/outputs/reports/PHASE2_DEMO_COUNTDOWN.md
 M xau-usd/xauusd-phase1/outputs/reports/PHASE2_DEMO_PREFLIGHT.json
 M xau-usd/xauusd-phase1/outputs/reports/PHASE2_DEMO_PREFLIGHT_REPORT.md
 M xau-usd/xauusd-phase1/outputs/reports/PHASE2_OWNER_ACTION_PACKET.json
 M xau-usd/xauusd-phase1/outputs/reports/PHASE2_OWNER_ACTION_PACKET.md
 M xau-usd/xauusd-phase1/outputs/reports/PHASE2_READINESS_REPORT.md
 M xau-usd/xauusd-phase1/outputs/reports/PHASE2_VPS_BOOTSTRAP_PACKET.json
 M xau-usd/xauusd-phase1/outputs/reports/PHASE2_VPS_BOOTSTRAP_PACKET.md
 M xau-usd/xauusd-phase1/outputs/reports/PHASE2_VPS_FIRST_DAY_VERIFICATION.json
 M xau-usd/xauusd-phase1/outputs/reports/PHASE2_VPS_FIRST_DAY_VERIFICATION.md
 M xau-usd/xauusd-phase1/outputs/reports/PHASE2_VPS_LATENCY_REPORT.md
 M xau-usd/xauusd-phase1/scripts/capture_phase2_vps_latency_evidence.ps1
 M xau-usd/xauusd-phase1/scripts/generate_phase1_bundle.py
 M xau-usd/xauusd-phase1/scripts/generate_phase1_review_index.py
 M xau-usd/xauusd-phase1/scripts/generate_phase2_demo_preflight_report.py
 M xau-usd/xauusd-phase1/scripts/generate_phase2_owner_action_packet.py
 M xau-usd/xauusd-phase1/scripts/generate_phase2_readiness_report.py
 M xau-usd/xauusd-phase1/scripts/generate_phase2_vps_bootstrap_packet.py
 M xau-usd/xauusd-phase1/scripts/generate_phase2_vps_first_day_verification.py
 M xau-usd/xauusd-phase1/scripts/generate_phase2_vps_latency_report.py
 M xau-usd/xauusd-phase1/scripts/generate_project_status_page.py
 M xau-usd/xauusd-phase1/scripts/install_phase2_periodic_checks_task.ps1
 M xau-usd/xauusd-phase1/scripts/run_phase1_periodic_checks.py
 M xau-usd/xauusd-phase1/scripts/verify_phase2_transition_artifacts.py
 M xau-usd/xauusd-phase1/scripts/verify_status_dashboard_freshness.py
 M xau-usd/xauusd-phase1/tests/test_agent_handoff.py
 M xau-usd/xauusd-phase1/tests/test_periodic_checks.py
 M xau-usd/xauusd-phase1/tests/test_phase1_bundle.py
 M xau-usd/xauusd-phase1/tests/test_phase1_review_index.py
 M xau-usd/xauusd-phase1/tests/test_phase2_demo_preflight_report.py
 M xau-usd/xauusd-phase1/tests/test_phase2_owner_action_packet.py
 M xau-usd/xauusd-phase1/tests/test_phase2_owner_approval_docs.py
 M xau-usd/xauusd-phase1/tests/test_phase2_readiness_report.py
 M xau-usd/xauusd-phase1/tests/test_phase2_scheduler_setup.py
 M xau-usd/xauusd-phase1/tests/test_phase2_transition_artifacts.py
 M xau-usd/xauusd-phase1/tests/test_phase2_vps_bootstrap_packet.py
 M xau-usd/xauusd-phase1/tests/test_phase2_vps_first_day_verification.py
 M xau-usd/xauusd-phase1/tests/test_phase2_vps_latency_report.py
 M xau-usd/xauusd-phase1/tests/test_project_status_page.py
 M xau-usd/xauusd-phase3-experimental/README.md
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_COMPLETION_AUDIT.json
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_COMPLETION_AUDIT.md
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_COST_GATE_REVIEW.csv
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_COST_GATE_REVIEW.json
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_COST_GATE_REVIEW.md
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_COST_MODE_COMPARISON.csv
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_COST_MODE_COMPARISON.json
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_COST_MODE_COMPARISON.md
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_DEMO_REHEARSAL_CHECKLIST.md
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_DEMO_REHEARSAL_LEDGER.csv
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_DEMO_REHEARSAL_PLAN.json
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_EXPERIMENTAL_LEDGER.csv
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_EXPERIMENTAL_MANIFEST.json
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_EXPERIMENTAL_MANIFEST.md
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_EXPERIMENTAL_SAFETY_REPORT.json
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_EXPERIMENTAL_SIMULATION.json
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_EXPERIMENTAL_SIMULATION.md
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_EXPERIMENTAL_STATUS.json
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_EXPERIMENTAL_STATUS.md
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_FAMILY_DEDUP_AUDIT.csv
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_FAMILY_DEDUP_AUDIT.json
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_FAMILY_DEDUP_AUDIT.md
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_LIFECYCLE_GUARD_LEDGER.csv
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_LIFECYCLE_GUARD_SUMMARY.json
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_LIFECYCLE_GUARD_SUMMARY.md
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_PAPER_SHADOW_LEDGER.csv
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_PAPER_SHADOW_SUMMARY.json
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_PAPER_SHADOW_SUMMARY.md
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_SHADOW_LIFECYCLE_LEDGER.csv
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_SHADOW_LIFECYCLE_SUMMARY.json
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_SHADOW_LIFECYCLE_SUMMARY.md
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_SUSPEND_FAMILY_DECISION.json
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_SUSPEND_FAMILY_REVIEW.json
 M xau-usd/xauusd-phase3-experimental/outputs/reports/PHASE3_SUSPEND_FAMILY_REVIEW.md
 M xau-usd/xauusd-phase3-experimental/outputs/review_bundles/PHASE3_EXPERIMENTAL_REVIEW_BUNDLE_LATEST.zip
 M xau-usd/xauusd-phase3-experimental/outputs/review_bundles/PHASE3_EXPERIMENTAL_REVIEW_BUNDLE_LATEST_manifest.json
 M xau-usd/xauusd-phase3-experimental/scripts/generate_phase3_completion_audit.py
 M xau-usd/xauusd-phase3-experimental/scripts/generate_phase3_experimental_manifest.py
 M xau-usd/xauusd-phase3-experimental/scripts/generate_phase3_experimental_status.py
 M xau-usd/xauusd-phase3-experimental/scripts/generate_phase3_review_bundle.py
 M xau-usd/xauusd-phase3-experimental/scripts/verify_phase3_experimental_artifacts.py
 M xau-usd/xauusd-phase3-experimental/tests/test_phase3_experimental.py
?? xau-usd/xauusd-phase1/scripts/generate_phase2_demo_next_actions_report.py
?? xau-usd/xauusd-phase1/scripts/generate_phase2_vps_selection_decision_check.py
?? xau-usd/xauusd-phase1/scripts/prepare_phase2_vps_evidence_workspace.ps1
?? xau-usd/xauusd-phase1/tests/test_phase2_demo_next_actions_report.py
?? xau-usd/xauusd-phase1/tests/test_phase2_vps_evidence_workspace.py
?? xau-usd/xauusd-phase1/tests/test_phase2_vps_selection_decision_check.py
?? xau-usd/xauusd-phase3-experimental/scripts/generate_phase3_to_demo_handoff.py
```

## Source Hashes

| Name | Exists | Bytes | SHA256 | Path |
| --- | --- | ---: | --- | --- |
| phase1_status_summary | True | 3191 | 87c51267a58dd02a48f7a1bba689b363a44b49b9e3accc4f25d8366b981818e8 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase1\outputs\reports\PHASE1_STATUS_SUMMARY.json |
| phase2_readiness_report | True | 6529 | 5454837d6ca06c60300a99d7df020d7d11a8aadfbce0a68c19dc61adcd679d1b | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase1\outputs\reports\PHASE2_READINESS_REPORT.md |
| phase3_completion_audit_json | True | 12430 | f64d6b33aca40e055851e368beb0209b32566d79eec55e47924bb4b821d1fc26 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_COMPLETION_AUDIT.json |
| phase3_completion_audit_md | True | 9096 | afb6d72e27cba7790658c7e657a263c68578a14eb8c0109780623ea5917c2c80 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_COMPLETION_AUDIT.md |
| phase3_cost_gate_review_csv | True | 1621 | 51c7756484d4ea9e165bacee1294cbac1b9ec219c103eed1affba62d2172f666 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_COST_GATE_REVIEW.csv |
| phase3_cost_gate_review_json | True | 8705 | 116810becd7137175af4e6da2a95874c487a6f8a20acedd4769174b0ba2810fb | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_COST_GATE_REVIEW.json |
| phase3_cost_gate_review_md | True | 3997 | 672718f85d930a1412695f627fd29ef7376ec127a6cbcfdf563b1f9919c7fb24 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_COST_GATE_REVIEW.md |
| phase3_cost_mode_comparison_csv | True | 971 | 8a804f24c64fc99fddb35f9598f7a7d2fd54fe2beedd9f72f98571adaa1b02cd | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_COST_MODE_COMPARISON.csv |
| phase3_cost_mode_comparison_json | True | 3724 | 7b63130d65b7f6a91122daf28a6105205a52f0227060ce9bb35a642ca453046a | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_COST_MODE_COMPARISON.json |
| phase3_cost_mode_comparison_md | True | 1569 | a96148d97991da7bf88030f7ed2ea801444bba1d7e02a686543f6e94deaffb66 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_COST_MODE_COMPARISON.md |
| phase3_demo_rehearsal_checklist_md | True | 3889 | b69213340d8e0fdc5720ea2c4447166bf0d3bd45f9bbe2dac97ab76161ca9348 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_DEMO_REHEARSAL_CHECKLIST.md |
| phase3_demo_rehearsal_ledger_csv | True | 44353 | 653fc0d09dbf91b61e8615205308aaa1c507cafff09419dfccc8ae65769ffeef | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_DEMO_REHEARSAL_LEDGER.csv |
| phase3_demo_rehearsal_plan_json | True | 2307 | 5e4caea455749fb7dfc87f3d726ec0889105595c6c59067f03a9c7af0ce4c68f | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_DEMO_REHEARSAL_PLAN.json |
| phase3_design_doc | True | 5696 | 7c9e77456fef038f1d9f4c3d2e66d222ca02a0c672b5fd6e7f2b1538b9b381ae | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\docs\PHASE3_EXECUTION_READINESS_DESIGN.md |
| phase3_experimental_ledger_csv | True | 79172 | 0adac372fb6578f72df318dc017c9afac9a8d7c6a0b4381a132a0ad52265855d | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_EXPERIMENTAL_LEDGER.csv |
| phase3_family_dedup_audit_csv | True | 11325 | a5192afd8fce30385d2987568c24de1e07deb11f8b46c88299817f05f876b3e9 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_FAMILY_DEDUP_AUDIT.csv |
| phase3_family_dedup_audit_json | True | 38167 | ec8f733642f5b9c361639a577318797ef93d345c02348ff0d564b69aabfafdd3 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_FAMILY_DEDUP_AUDIT.json |
| phase3_family_dedup_audit_md | True | 10575 | 452dcdc851013e78aadaa4a539ca777f7d5701f1815d365e9dce9aa465f94aed | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_FAMILY_DEDUP_AUDIT.md |
| phase3_freeze_doc | True | 1499 | 41f0423e6771eee3a8e29ae7459afea59ad2859bcc04ba519fe39f21b3f483d7 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\docs\PHASE3_EXPERIMENTAL_FREEZE.md |
| phase3_input_would_signals | True | 32689 | 5a22bb4163618cc82a7e80fd0587edee13f1c74f29e361e562fac8547870c1b1 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase1\outputs\reports\PHASE1_WOULD_SIGNAL_REVIEW.csv |
| phase3_lifecycle_guard_ledger_csv | True | 54115 | 11560a754ef128213af35a7f95cc57c8f77732a438037391f734e3eead607b63 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_LIFECYCLE_GUARD_LEDGER.csv |
| phase3_lifecycle_guard_summary_json | True | 2350 | eea25b09a10615e06b3ee4ffe357426753f48fbeec6d9314508d8faaf3baefb7 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_LIFECYCLE_GUARD_SUMMARY.json |
| phase3_lifecycle_guard_summary_md | True | 4288 | 37a47f1709e67f770bfab7d98d406be4a2907982bbc8c504a7e223eaa504978c | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_LIFECYCLE_GUARD_SUMMARY.md |
| phase3_observer_conflict_playbook | True | 1981 | 61871c85c043cbb34be86df874943c4cd31e2a4c6a2e9d03c3f922d60a4449be | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\docs\PHASE3_OBSERVER_CONFLICT_PLAYBOOK.md |
| phase3_paper_shadow_ledger_csv | True | 61913 | b01d73511891ddaa98ec1543d623adff6d2c8faaac0e4dda227f1f8925c6c744 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_PAPER_SHADOW_LEDGER.csv |
| phase3_paper_shadow_summary_json | True | 1984 | 9d015c36530f2b2f9ad7f9cac09da310fc2d20e3a153381590c1c070e831e158 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_PAPER_SHADOW_SUMMARY.json |
| phase3_paper_shadow_summary_md | True | 4088 | f2c651e72535b90932fb1f3ceb5099aba5b9f5ff6f2c2f045f7d09b76e4bfa18 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_PAPER_SHADOW_SUMMARY.md |
| phase3_promotion_rollback_doc | True | 3888 | e3d44bd18cc479ccc62e7e7215d8e0f567482602a48e1995b757f5f0ce19b688 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\docs\PHASE3_PROMOTION_ROLLBACK_CRITERIA.md |
| phase3_real_implementation_prompt | True | 2031 | f66cc798ad386212e7674d4d37a6e51517be54f711af4a39c366e9fe51109dff | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\docs\PHASE3_REAL_IMPLEMENTATION_PROMPT.md |
| phase3_review_bundle_latest_manifest | True | 6440 | e49f4e6d17e2d4f3f1d67f1ffce693f11f9b3e8faaccfde3bf22fc0ca6941f5a | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\review_bundles\PHASE3_EXPERIMENTAL_REVIEW_BUNDLE_LATEST_manifest.json |
| phase3_review_bundle_latest_zip | True | 104118 | 62205bc26339ae245986ef4195ae33d9cbfc7f5628aed97a6ef070ac4b7892b1 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\review_bundles\PHASE3_EXPERIMENTAL_REVIEW_BUNDLE_LATEST.zip |
| phase3_safety_json | True | 664 | 2a61b5f972b704bb7faa26503ca323c8345c1589a3c5d0895f77c07e58decb0b | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_EXPERIMENTAL_SAFETY_REPORT.json |
| phase3_safety_md | True | 570 | 7c311b34722e50380a542d92004067c38bc02d75ce9d7f02a1ca192823a91ba3 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_EXPERIMENTAL_SAFETY_REPORT.md |
| phase3_scope_doc | True | 5520 | 978d59a39372d85d2c04a409dd56affd30d5fabd8cc4ff35263598ea5a011173 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\docs\PHASE3_EXPERIMENTAL_SCOPE.md |
| phase3_shadow_lifecycle_ledger_csv | True | 69382 | fe0ddeeafe7ef408ead83e3cf45a0afcc8c79fbeecfc46668440a62ddf6f84bb | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_SHADOW_LIFECYCLE_LEDGER.csv |
| phase3_shadow_lifecycle_summary_json | True | 2334 | f6ffc565cfcb416de8a51cccfd70fa878c66627a6443d1b31b666bdc8e5aae8a | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_SHADOW_LIFECYCLE_SUMMARY.json |
| phase3_shadow_lifecycle_summary_md | True | 4200 | 2235bbe918946d35f1c8f674a3b22a13ce866d35b0f99cde35a5b9deb4c15746 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_SHADOW_LIFECYCLE_SUMMARY.md |
| phase3_simulation_json | True | 2007 | 2e215ee0a3a133c031c3ef189ab69698dec348c655f94345bf4401ba44a6c788 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_EXPERIMENTAL_SIMULATION.json |
| phase3_simulation_md | True | 3747 | 415bc362b46949b112ce588d435765dcecd040b071a67a98a6600dbc9bbb2063 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_EXPERIMENTAL_SIMULATION.md |
| phase3_status_json | True | 12855 | b075392cd7e7cbd2079323307a2c8c128bcce69a93a6a96832a569533774819b | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_EXPERIMENTAL_STATUS.json |
| phase3_status_md | True | 3734 | ef76c9a239bf04d44201cd753909e0952fa2e15078638b564ad64b8fbab82adf | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_EXPERIMENTAL_STATUS.md |
| phase3_suspend_family_csv | True | 6886 | 1e903aaeae6a8e3a3afe3d2370515a5f2badb66a6b9ce52599b79c73ffb90e38 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_SUSPEND_FAMILY_ROWS.csv |
| phase3_suspend_family_decision_csv | True | 3733 | 31ba16d1d42b25b4dfcbcec38803741e583ed08a4b4483891055156a116f0a9d | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_SUSPEND_FAMILY_DECISION.csv |
| phase3_suspend_family_decision_json | True | 10147 | cefbc2dc47d6fe0c88972e4094c567121250e6b8eb50cffc51027cb8f13f2047 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_SUSPEND_FAMILY_DECISION.json |
| phase3_suspend_family_decision_md | True | 3286 | 3fb2190bc92d2ed57d60480bb60e4c068121ab1b850b97b47d5179b279f38f27 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_SUSPEND_FAMILY_DECISION.md |
| phase3_suspend_family_json | True | 2062 | 4524b910245d6f57265876ef1539d895ece4b47bca1393bb0b3c26c44e6bd22e | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_SUSPEND_FAMILY_REVIEW.json |
| phase3_suspend_family_md | True | 5010 | e9168f8ef51ff6d56f6342df9f1b630ec5aa6ad0d17a90cbd879d221a6f76ae6 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_SUSPEND_FAMILY_REVIEW.md |
| phase3_to_demo_handoff_json | True | 8486 | a75a75a7198096ff782fa7450b895dd97d28e226d4950e49b3b812e9ee7336a6 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_TO_DEMO_HANDOFF.json |
| phase3_to_demo_handoff_md | True | 6406 | 3af6f4f1425693871fa767c81f520b4ea38519224a5064427d361094895a5999 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\outputs\reports\PHASE3_TO_DEMO_HANDOFF.md |
| script_artifact_verifier | True | 13656 | 3e6132c8d22ccbff2f9ea4044694a3ed48dbe207de6e7b0ecc4e5e20b3688aca | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\scripts\verify_phase3_experimental_artifacts.py |
| script_completion_audit | True | 19212 | d5be5787459d77ad41a748ee0ef349f86c007195db9b00f29c8d3758a2a876cc | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\scripts\generate_phase3_completion_audit.py |
| script_cost_gate_review | True | 12615 | 2a34b873ac58faac702ab7b423c2fc02d6b4d377bbe2e1147af1e7994cfeac21 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\scripts\generate_phase3_cost_gate_review.py |
| script_cost_mode_comparison | True | 7963 | 811341903c70125ac37875cc3a9a3dcd16b71a319498fca743981d3d25e625e4 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\scripts\generate_phase3_cost_mode_comparison.py |
| script_demo_handoff | True | 11510 | ac949181e429c05e5ed5ad2e12ef41defd1bad555c7a240b5bd3002fbaf553e3 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\scripts\generate_phase3_to_demo_handoff.py |
| script_demo_rehearsal_package | True | 15833 | 16f0cfba480faa6aae77417c69dd6ee93ec62b4e5860c8af662ac4b4f1e263f6 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\scripts\generate_phase3_demo_rehearsal_package.py |
| script_family_dedup_audit | True | 8359 | 662d3f5ffc55cd60581b0026ee8bedadb443d85aa92b2b7eab74dd81a722c66b | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\scripts\generate_phase3_family_dedup_audit.py |
| script_lifecycle_guard_experiment | True | 17046 | b359ce26a1bda76e197ffe251712708651d6ae3e935bfce37cb260e75ab492b7 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\scripts\generate_phase3_lifecycle_guard_experiment.py |
| script_manifest | True | 13352 | b628925ff969537e281fbd0c8552ca38b3c85d666dee93515d51fdd379922af0 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\scripts\generate_phase3_experimental_manifest.py |
| script_paper_shadow_experiment | True | 17334 | 996ede552ab866ae1224d15241bfaff360c447d62c0d4efc5f0029c4f5ce9dff | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\scripts\generate_phase3_paper_shadow_experiment.py |
| script_review_bundle | True | 5388 | 3eb6b5967ee96e3b5c103692630cd1e9e7f5dbcb86ba1a795b621fa9b8e0ae6b | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\scripts\generate_phase3_review_bundle.py |
| script_safety | True | 6615 | b90a5815e106ae1085f9a44014faafb1d809731a95260acdf220fdafec3325e8 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\scripts\audit_phase3_experimental_safety.py |
| script_shadow_lifecycle_experiment | True | 16600 | 870bf3e34c554beb2f2d0b945a8d35fc5d7a57607585966c9dbe503fd465bdf6 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\scripts\generate_phase3_shadow_lifecycle_experiment.py |
| script_simulation | True | 24283 | d6f88b84457a38d4545a214f659d11125802229cb3ce81b8964045b37a615e1c | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\scripts\simulate_phase3_from_would_signals.py |
| script_status | True | 28048 | a319c9ebcec828efb8a9106d1147ccf9b3d0719a385937b018b1dd2bdb6013b2 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\scripts\generate_phase3_experimental_status.py |
| script_status_dashboard_freshness | True | 15859 | 5707d4beeec37443b987cacbeb6254bfcc0ba60be57500aa0b300b1c85540d02 | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase1\scripts\verify_status_dashboard_freshness.py |
| script_suspend_family_decision | True | 7827 | 523c1b56a92de426f8e53e4cf0ea175f29841efd8ad16f5d117af1505a9a463f | C:\Users\ZHAO ZHU INFORMATION\Downloads\algo-trading-system\xau-usd\xauusd-phase3-experimental\scripts\generate_phase3_suspend_family_decision.py |
